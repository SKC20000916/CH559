#include "Includes.h"

UINT8   Item_Display_Top = 0;//��ǰ��Ļ��һ����ʾ��ID
UINT8 func_index = 0;
void (*current_operation_index)();
bit key_exit = 0;




void main()
{
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/*
��һ���ֽ��г�ʼ���Լ���¼�����жϣ��ϵ�ֻ����һ�Ρ�
*/
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	Initialization();


//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/*
�����������в���
*/
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
   while(1)
   {
         /*******************find index****************************/
		if(!key_exit)
		{
			if((READ_DOWNLOAD_KEY == 0)||(READ_LEFT_KEY == 0)||(READ_RIGHT_KEY == 0))
			{
				DelayMsSW(30);										//����
				if(READ_LEFT_KEY == 0)
				{
					key_exit = 1;
					func_index=KeyTab[func_index].PressLeft;    	//���Ϸ�
				}
				if(READ_RIGHT_KEY == 0)
				{
					key_exit = 1;
					func_index=KeyTab[func_index].PressRight;    	//���·�
				}
				if(READ_DOWNLOAD_KEY == 0)
				{
					key_exit = 1;
					Item_Display_Top = 0;
					func_index=KeyTab[func_index].PressOk;    		//ȷ��
					LCD_Fill(0, 0, 240, 135, 0xFFFF);
				}
			}
		}
		else
		{
			if(READ_LEFT_KEY && READ_DOWNLOAD_KEY && READ_RIGHT_KEY)
			{
				key_exit = 0;
			}
		}
        current_operation_index=KeyTab[func_index].CurrentOperate;
        (*current_operation_index)();//ִ�е�ǰ��������
    }
}

