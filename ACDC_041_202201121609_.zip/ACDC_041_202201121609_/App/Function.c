#include "Function.h"

#define Item_Display_Max 4	//�궨����Ļ�����ʾ����
#define Item_Hight 33		//ÿ����ռ����





char *Display_Item[] = 
{
    "��",
        "��",
        "��",
            "����",
            "����",
        "����",
    "��",
        "��",
        "����",
    "��",
        "��",
        "��",
        "��",
        "��",
        "����",
    "��",
    "����",
    "����",
};



enum
{
    Menu0,				
        Menu0_0,		
        Menu0_1,		
            Menu0_1_0,
            Menu0_1_1,
        Menu0_2,	
    Menu1,				
        Menu1_0,		
        Menu1_1,		
    Menu2,				
        Menu2_0,		
        Menu2_1,		
        Menu2_2,		
        Menu2_3,		
        Menu2_4,		
    Menu3,				
    Menu4,	
    Menu5,
    //���幦��
    Menu0_0_Fun,
    // Menu0_2_Fun,
    Menu0_1_0_Fun,
    // Menu0_1_1_Fun,
    Menu1_0_Fun,
    // Menu1_1_Fun,
    Menu2_0_Fun,
    Menu2_1_Fun,
    Menu2_2_Fun,
    Menu2_3_Fun,
    // Menu2_4_Fun,
    Menu3_Fun,
    Menu4_Fun,
    Menu5_Fun,
}Menu_ID;



const struct KeyTabStruct KeyTab[]={

    //CurMenuID,            MaxMenuItem,    	OkMenuID,       	LeftMenuID,     RightMenuID,    CurFunction
	{Menu0,					6,					Menu0_0,			Menu5,			Menu1,			(*fun0)				},
    {    Menu0_0,			3,					Menu0_0_Fun,		Menu0_2,		Menu0_1,		    (*fun0_0)		},
    {    Menu0_1,			3,					Menu0_1_0,			Menu0_0,		Menu0_2,		    (*fun0_1)		},
    {        Menu0_1_0,		2,					Menu0_1_0_Fun,		Menu0_1_1,		Menu0_1_1,		        (*fun0_1_0)	},
    {        Menu0_1_1,		2,					Menu0_1,    		Menu0_1_0,		Menu0_1_0,		        (*fun0_1_1)	},
	{    Menu0_2,			3,					Menu0,      		Menu0_1,		Menu0_0,		     (*fun0_2)		},
    {Menu1,					6,					Menu1_0,			Menu0,			Menu2,			(*fun1)				},
    {    Menu1_0,			2,					Menu1_0_Fun,		Menu1_1,		Menu1_1,		    (*fun1_0)		},
    {    Menu1_1,			2,					Menu1,	        	Menu1_0,		Menu1_0,		    (*fun1_1)		},
    {Menu2,					6,					Menu2_0,			Menu1,			Menu3,			(*fun2)				},
    {    Menu2_0,			5,					Menu2_0_Fun,		Menu2_4,		Menu2_1,		    (*fun2_0)		},
    {    Menu2_1,			5,					Menu2_1_Fun,		Menu2_0,		Menu2_2,		    (*fun2_1)		},
    {    Menu2_2,			5,					Menu2_2_Fun,		Menu2_1,		Menu2_3,		    (*fun2_2)		},
    {    Menu2_3,			5,					Menu2_3_Fun,		Menu2_2,		Menu2_4,		    (*fun2_3)		},
    {    Menu2_4,			5,					Menu2   ,		Menu2_3,		Menu2_0,		    (*fun2_4)		},
    {Menu3,					6,					Menu3_Fun,			Menu2,			Menu4,			(*fun3)				},
    {Menu4,					6,					Menu4_Fun,			Menu3,			Menu5,			(*fun4)				},
    {Menu5,					6,					Menu5_Fun,			Menu4,			Menu0,			(*fun5)				},
	{Menu0_0_Fun,			0,					0,					0,				0,				(*function0)		},//����ʵ�ʹ���ʱ���������ɹ�������
	// {Menu0_2_Fun,		0,					0,					0,				0,				(*function1)		},//��Ϊ���ذ�������ʵ�ʹ���,ע�͵�
    {Menu0_1_0_Fun,			0,					0,					0,				0,				(*function2)		},
    // {Menu0_1_1_Fun,		0,					0,					0,				0,				(*function3)		},
    {Menu1_0_Fun,			0,					0,					0,				0,				(*function4)		},
    // {Menu1_1_Fun,		0,					0,					0,				0,				(*function5)		},
    {Menu2_0_Fun,			0,					0,					0,				0,				(*function6)		},
    {Menu2_1_Fun,			0,					0,					0,				0,				(*function7)		},
    {Menu2_2_Fun,			0,					0,					0,				0,				(*function8)		},
    {Menu2_3_Fun,			0,					0,					0,				0,				(*function9)		},
    // {Menu2_4_Fun,		0,					0,					0,				0,				(*function10)		},
    {Menu3_Fun,				0,					0,					0,				0,				(*function11)		},
    {Menu4_Fun,				0,					0,					0,				0,				(*function12)		},
    {Menu5_Fun,				0,					0,					0,				0,				(*function13)		},
};

void Display_Menu(UINT8 *Menu_Main)
{
    UINT8 i,j;
    for(j=0;j<KeyTab[func_index].MaxItems;j++)//j�ǲ˵���ʾ��������
    {
        if(Menu_Main[j] == func_index)
        {
            break;
        }
    }
    if((j >= Item_Display_Top + Item_Display_Max)||(j < Item_Display_Top))
    {
        LCD_Fill(0, 0, 240, 135, 0xFFFF);
        while(j >= Item_Display_Top + Item_Display_Max)
        {
            Item_Display_Top ++;
        }
        while(j < Item_Display_Top)
        {
            Item_Display_Top --;
        }
        
    }

    if(KeyTab[func_index].MaxItems > Item_Display_Max)
    {
        for(i=0;i<Item_Display_Max;i++)
        {
            if(i == j-Item_Display_Top)
            {
                LCD_ShowChinese(0,i*Item_Hight,Display_Item[Menu_Main[Item_Display_Top+i]],WHITE,RED,24,0);
            }
            else
            {
                LCD_ShowChinese(0,i*Item_Hight,Display_Item[Menu_Main[Item_Display_Top+i]],RED,WHITE,24,0);
            }
        }
    }
    else
    {
        for(i=0;i<KeyTab[func_index].MaxItems;i++)
        {
            if(i == j-Item_Display_Top)
            {
                LCD_ShowChinese(0,i*Item_Hight,Display_Item[Menu_Main[Item_Display_Top+i]],WHITE,RED,24,0);
            }
            else
            {
                LCD_ShowChinese(0,i*Item_Hight,Display_Item[Menu_Main[Item_Display_Top+i]],RED,WHITE,24,0);
            }
        }
    }
}






void fun0()
{
    UINT8 Menu_List[6] = {Menu0,Menu1,Menu2,Menu3,Menu4,Menu5};

    Display_Menu(Menu_List);
}				
void fun1()
{
    UINT8 Menu_List[6] = {Menu0,Menu1,Menu2,Menu3,Menu4,Menu5};

    Display_Menu(Menu_List);
}	
void fun2()
{
    UINT8 Menu_List[6] = {Menu0,Menu1,Menu2,Menu3,Menu4,Menu5};

    Display_Menu(Menu_List);
}		
void fun3()
{
    UINT8 Menu_List[6] = {Menu0,Menu1,Menu2,Menu3,Menu4,Menu5};

    Display_Menu(Menu_List);
}				
void fun4()
{
    UINT8 Menu_List[6] = {Menu0,Menu1,Menu2,Menu3,Menu4,Menu5};

    Display_Menu(Menu_List);
}	

void fun5()
{
    UINT8 Menu_List[6] = {Menu0,Menu1,Menu2,Menu3,Menu4,Menu5};

    Display_Menu(Menu_List);
}	

void fun0_0()
{
    UINT8 Menu_List[3] = {Menu0_0,Menu0_1,Menu0_2};

    Display_Menu(Menu_List);
}		
void fun0_1()
{
    UINT8 Menu_List[3] = {Menu0_0,Menu0_1,Menu0_2};

    Display_Menu(Menu_List);
}		
void fun0_1_0()
{
    UINT8 Menu_List[2] = {Menu0_1_0,Menu0_1_1};

    Display_Menu(Menu_List);
}
void fun0_1_1()
{
    UINT8 Menu_List[2] = {Menu0_1_0,Menu0_1_1};

    Display_Menu(Menu_List);
}
void fun0_2()
{
    UINT8 Menu_List[3] = {Menu0_0,Menu0_1,Menu0_2};

    Display_Menu(Menu_List);
}		

void fun1_0()
{
    UINT8 Menu_List[2] = {Menu1_0,Menu1_1};

    Display_Menu(Menu_List);
}		
void fun1_1()
{
    UINT8 Menu_List[2] = {Menu1_0,Menu1_1};

    Display_Menu(Menu_List);
}		
	
void fun2_0()
{
    UINT8 Menu_List[5] = {Menu2_0,Menu2_1,Menu2_2,Menu2_3,Menu2_4};

    Display_Menu(Menu_List);
}		
void fun2_1()
{
    UINT8 Menu_List[5] = {Menu2_0,Menu2_1,Menu2_2,Menu2_3,Menu2_4};

    Display_Menu(Menu_List);
}		
void fun2_2()
{
    UINT8 Menu_List[5] = {Menu2_0,Menu2_1,Menu2_2,Menu2_3,Menu2_4};

    Display_Menu(Menu_List);
}		
void fun2_3()
{
    UINT8 Menu_List[5] = {Menu2_0,Menu2_1,Menu2_2,Menu2_3,Menu2_4};

    Display_Menu(Menu_List);
}		
void fun2_4()
{
    UINT8 Menu_List[5] = {Menu2_0,Menu2_1,Menu2_2,Menu2_3,Menu2_4};

    Display_Menu(Menu_List);
}		
			
void function0()
{

}		
// void function1()
// {
    
// }		
void function2()
{
    
}			
// void function3()
// {
    
// }			
void function4()
{
    
}			
// void function5()
// {
    
// }			
void function6()
{
    
}			
void function7()
{
    
}			
void function8()
{
    
}			
void function9()
{
    
}			
// void function10()
// {
    
// }			
void function11()
{
    
}			
void function12()
{
    
}			
void function13()
{
    
}	