#ifndef _ZJY114T_IG01_H__
#define _ZJY114T_IG01_H__

#include "Includes.h"



void InitLCD();
void LCD_SetAddr(u16 startX, u16 startY, u16 endX, u16 endY);
void LCD_Fill(u16 startX, u16 startY, u16 endX, u16 endY, u16 color);
void LCD_DrawPoint(u16 x, u16 y, u16 color);
void LCD_ShowChinese32x32(u16 x,u16 y,u8 *s,u16 fc,u16 bc,u8 sizey,u8 mode);
void LCD_ShowChinese(u16 x,u16 y,u8 *s,u16 fc,u16 bc,u8 sizey,u8 mode);
void LCD_ShowChar(u16 x,u16 y,u8 num,u16 fc,u16 bc,u8 sizey,u8 mode);
u32 mypow(u8 m,u8 n);
void LCD_ShowIntNum(u16 x,u16 y,u16 num,u8 len,u16 fc,u16 bc,u8 sizey);
#endif