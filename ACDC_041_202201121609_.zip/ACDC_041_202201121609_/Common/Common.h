#ifndef _COMMON_H__
#define _COMMON_H__

#include "Includes.h"

typedef void( *pTaskFn)(void);

void Initialization();
void InitGPIO();
void InitDownload();
void JumpToBootloader();
void DelayUs(uint16_t us);
void DelayMsSW(uint16_t ms);

#endif
