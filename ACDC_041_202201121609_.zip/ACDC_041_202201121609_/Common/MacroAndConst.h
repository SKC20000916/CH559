#ifndef _MACROANDCONST_H__
#define _MACROANDCONST_H__

#define true						(1)
#define false						(0)

#define SWAP_16BITS(a) \
    ((((a) & 0xFF00) >> 8) | (((a) & 0x00FF) << 8))

#define SWAP_32BITS(a) \
    ((((a) & 0xFF000000) >> 24) | (((a) & 0x00FF0000) >> 8) | \
		(((a) & 0x0000FF00) << 8)  | (((a) & 0x000000FF) << 24))

typedef bit							bool;

typedef unsigned char				uint8_t;
typedef unsigned char				u8;
typedef signed char					int8_t;
typedef signed char					s8;

typedef unsigned short				uint16_t;
typedef unsigned short				u16;
typedef signed short				int16_t;
typedef signed short				s16;

typedef unsigned long				uint32_t;
typedef unsigned long				u32;
typedef signed long					int32_t;
typedef signed long					s32;
#endif