#ifndef _INCLUDES_H__
#define _INCLUDES_H__

#define NO_XSFR_DEFINE

#include <stdio.h>
#include <string.h>
#include "CH559.h"
#include "MacroAndConst.h"
#include "Config.h"
#include "Common.h"
#include "System.h"
#include "LED.h"
#include "Key.h"
#include "UART.h"
#include "LCD.h"
#include "USB.h"
#include "USB_Descriptor.h"
#include "I2C.h"
#include "ZJY114T_IG01.h"
#include "ImageCode.h"
#include "DataFlash.h"
#include "Function.h"
#endif
