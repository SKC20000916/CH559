#ifndef _CONFIG_H__
#define _CONFIG_H__

#define TOUCH_DEVICE_ADDRESS			(0x3C)

#define I2C_TOUCH_DATA_BUF_ADD			(0x40010000)
#define I2C_TOUCH_DATA_COUNT_ADD		(0x40010084)

#define EXTERNAL_OSC_ENABLE				(FALSE)
#define	SYSTEM_FREQUENCY				(56000000)

#define UART0_BAUDRATE					(500000)

#endif 
