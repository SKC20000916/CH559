#include "Common.h"

pTaskFn tasksArr[1];

void Initialization()
{
	InitSystemClock();
	InitGPIO();
	InitGPIO_LED();
	InitUART0();
	InitGPIO_Key();
	InitDownload();
	InitGPIO_LCD();
	InitLCD();
	// InitGPIO_I2C();
	// InitUSB_Device();
	EA = 1;

	
}

void InitGPIO()
{
	PORT_CFG &= ~bP0_OC;
	PORT_CFG |= bP0_DRV;

	PORT_CFG &= ~bP1_OC;
	PORT_CFG |= bP1_DRV;

	PORT_CFG |= bP2_OC;

	PORT_CFG |= bP3_OC;
	PORT_CFG |= bP3_DRV;
}

void InitDownload()
{
	if (READ_DOWNLOAD_KEY == 0)
	{
		DelayMsSW(30);
		if (READ_DOWNLOAD_KEY == 0)
		{
			JumpToBootloader();
		}
	}
	
}

void JumpToBootloader()
{
	EA = 0;                                                                    //关闭总中断，必加
	tasksArr[0] = BOOT_LOAD_ADDR;			
	(tasksArr[0])();  
	while (1);
}

// void DelayUs(uint16_t us)
// {
// 	while (us)
// 	{ 
// 		++SAFE_MOD; 
// 		++SAFE_MOD;
// 		++SAFE_MOD;
// 		++SAFE_MOD;
// 		++SAFE_MOD;
// 		++SAFE_MOD; 
// 		++SAFE_MOD;
// 		++SAFE_MOD;
// 		++SAFE_MOD;
// 		++SAFE_MOD;
// 		++SAFE_MOD; 
// 		++SAFE_MOD;
// 		++SAFE_MOD;
// 		++SAFE_MOD;
// 		++SAFE_MOD;
// 		++SAFE_MOD; 
// 		++SAFE_MOD;
// 		++SAFE_MOD;
// 		++SAFE_MOD;
// 		++SAFE_MOD;
// 		++SAFE_MOD;
// 		++SAFE_MOD;
// 		++SAFE_MOD;
// 		--us;
// 	}
// }

void DelayMsSW(uint16_t ms)
{
	uint16_t xdata i,j;

	for (i = 0; i < ms; i++)
		for (j = 0; j < 4600; j++);		
}
