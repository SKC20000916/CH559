#include "USB.h"

// #define THIS_ENDP0_SIZE         MAX_PACKET_SIZE
// #define UsbSetupBuf     ((PUSB_SETUP_REQ)Ep0Buffer)


// HID_IF_CTX xdata HidIfCtx = {0};
// UINT8X UsbRecFlag = 0;

// UINT8X Ep0Buffer[MAX_PACKET_SIZE]	_at_ 0x0000;														//端点0 OUT&IN缓冲区，必须是偶地址
// UINT8X Ep1Buffer[MAX_PACKET_SIZE]	_at_ 0x0040;														//端点1 IN缓冲区,必须是偶地址
// UINT8X DataBuffer[MAX_PACKET_SIZE]	_at_ 0x0080;

// #pragma  NOAREGS

// bool bIsUsbConnected = false;

// static uint16_t u16Ep0RemainLen;
// static uint8_t *pEp0Data;
// static uint8_t u8bRequest;
// static uint8_t UsbDeviceAddr = 0;

// static void UsbEp0Setup(void);
// static void UsbEp0Stall(void);
// static void UsbEp0In(void);
// static void UsbEp0Out(void);
// static void UsbEp1In(void);

// void InitUSB_Device()
// {
// 	IE_USB = 0;
// 	USB_CTRL = 0x00;															// 先设定USB设备模式
// 	UDEV_CTRL = bUD_DP_PD_DIS | bUD_DM_PD_DIS;									// 禁止DP/DM下拉电阻
//     UDEV_CTRL &= ~bUD_LOW_SPEED;												//选择全速12M模式，默认方式
//     USB_CTRL &= ~bUC_LOW_SPEED;
//     UEP0_DMA = Ep0Buffer;														//端点0数据传输地址
//     UEP4_1_MOD &= ~(bUEP4_RX_EN | bUEP4_TX_EN);									//端点0单64字节收发缓冲区
//     UEP0_CTRL = UEP_R_RES_ACK | UEP_T_RES_ACK;									//OUT事务返回ACK，IN事务返回NAK
//     UEP1_DMA = Ep1Buffer;														//端点1数据传输地址
//     UEP4_1_MOD = UEP4_1_MOD & ~bUEP1_BUF_MOD | bUEP1_TX_EN;						//端点1发送使能 64字节缓冲区
//     UEP1_CTRL = bUEP_AUTO_TOG | UEP_T_RES_NAK;									//端点1自动翻转同步标志位，IN事务返回NAK	
		
// 	USB_DEV_AD = 0x00;
// 	USB_CTRL |= bUC_DEV_PU_EN | bUC_INT_BUSY | bUC_DMA_EN;						// 启动USB设备及DMA，在中断期间中断标志未清除前自动返回NAK
// 	UDEV_CTRL |= bUD_PORT_EN;													// 允许USB端口
// 	USB_INT_FG = 0xFF;															// 清中断标志
// 	USB_INT_EN = bUIE_SUSPEND | bUIE_TRANSFER | bUIE_BUS_RST;
// 	IE_USB = 1;
// }

// bool UsbEp1SendBuf(uint8_t *pBuf, uint8_t len)
// {
//     memcpy(Ep1Buffer, pBuf, len);																		//加载上传数据
//     UEP1_T_LEN = len;																					//上传数据长度
//     UEP1_CTRL = UEP1_CTRL & ~ MASK_UEP_T_RES | UEP_T_RES_ACK;											//有数据时上传数据并应答ACK
// 	return true;
// }


// void Enp1IntIn(void)
// {
//     // memcpy( Ep1Buffer, HIDKey, sizeof(HIDKey));                              //加载上传数据
//     // UEP1_T_LEN = sizeof(HIDKey);                                             //上传数据长度
//     UEP1_CTRL = UEP1_CTRL & ~ MASK_UEP_T_RES | UEP_T_RES_ACK;                //有数据时上传数据并应答ACK
// }


// void DeviceInterrupt(void) interrupt INT_NO_USB using 1                      //USB中断服务程序,使用寄存器组1
// {
//     UINT16 len = 0;
//     if(UIF_TRANSFER)                                                            //USB传输完成标志
//     {
//         switch (USB_INT_ST & (MASK_UIS_TOKEN | MASK_UIS_ENDP))
//         {
//         case UIS_TOKEN_IN | 1:                                                  //endpoint 1# 中断端点上传
// 			UsbEp1In();
//             break;

//         case UIS_TOKEN_SETUP | 0:                                                //SETUP事务
// 			UsbEp0Setup();
//             break;

//         case UIS_TOKEN_IN | 0:                                               //endpoint0 IN
// 			UsbEp0In();
//             break;

//         case UIS_TOKEN_OUT | 0:																			// endpoint0 OUT
// 			UsbEp0Out();			
//             break;

//         default:
//             break;
//         }
//         UIF_TRANSFER = 0;                                                 //写0清空中断
//     }
//     if(UIF_BUS_RST)                                                       //设备模式USB总线复位中断
//     {
//         UEP0_CTRL = UEP_R_RES_ACK | UEP_T_RES_NAK;
//         UEP1_CTRL = bUEP_AUTO_TOG | UEP_R_RES_ACK;
//         UEP2_CTRL = bUEP_AUTO_TOG | UEP_R_RES_ACK | UEP_T_RES_NAK;
//         USB_DEV_AD = 0x00;
//         UIF_SUSPEND = 0;
//         UIF_TRANSFER = 0;
//         UIF_BUS_RST = 0;                                                 //清中断标志
//     }
//     if (UIF_SUSPEND)                                                     //USB总线挂起/唤醒完成
//     {
//         UIF_SUSPEND = 0;
//         if ( USB_MIS_ST & bUMS_SUSPEND )                                 //挂起
//         {
// //             while ( XBUS_AUX & bUART0_TX );                              //等待发送完成
// //             SAFE_MOD = 0x55;
// //             SAFE_MOD = 0xAA;
// //             WAKE_CTRL = bWAK_BY_USB | bWAK_RXD0_LO;                      //USB或者RXD0有信号时可被唤醒
// //             PCON |= PD;                                                  //睡眠
// //             SAFE_MOD = 0x55;
// //             SAFE_MOD = 0xAA;
// //             WAKE_CTRL = 0x00;
//         }
//     }
//     else {                                                               //意外的中断,不可能发生的情况
//         USB_INT_FG = 0xFF;                                               //清中断标志
// //      printf("UnknownInt  N");
//     }
// }

// static void UsbEp0Setup(void)
// {
// 	bool bRet = true;
// 	uint16_t u16Len = 0;
// 	uint16_t u16ReqLen = (UsbSetupBuf->wLengthH << 8) | UsbSetupBuf->wLengthL;

// 	u16Len = USB_RX_LEN;
// 	if (u16Len == sizeof(USB_SETUP_REQ))
// 	{
// 		u16Len = 0;
// 		u8bRequest = UsbSetupBuf->bRequest;
// 		if ((UsbSetupBuf->bRequestType & USB_REQ_TYP_MASK) != USB_REQ_TYP_STANDARD )					//HID类命令
// 		{
// 			// printf("Req0=%d\r\n", (uint16_t)u8bRequest);
// 			switch (u8bRequest)
// 			{
// 				case HID_GET_REPORT:
// 					{
// 						// printf("wvh=%d\r\n", (uint16_t)UsbSetupBuf->wValueH);
// 						if (UsbSetupBuf->wValueH == HID_REPORT_TYPE_INPUT_REPORT)
// 						{
// 							/* code */
// 						}
// 						else if (UsbSetupBuf->wValueH == HID_REPORT_TYPE_FEATURE_REPORT)
// 						{
// 							// printf("wvl=%d\r\n", (uint16_t)UsbSetupBuf->wValueL);
// 							switch (UsbSetupBuf->wValueL)
// 							{
// 								case REPORT_ID_CUBER_DATA:
// 									DataBuffer[0] = REPORT_ID_CUBER_DATA;
// 									pEp0Data= (uint8_t *)DataBuffer;
// 									u16Len = u16ReqLen;
// 									break;

// 								case REPORT_ID_MAX_CONTACT:
// 									DataBuffer[0] = REPORT_ID_MAX_CONTACT;
// 									DataBuffer[1] = MAX_CONTACT_POINTS;
// 									DataBuffer[2] = 0;
// 									pEp0Data= (uint8_t *)DataBuffer;
// 									u16Len = 3;
// 									break;
								
// 								default:
// 									bRet = false;
// 									break;
// 							}
// 						}
						
						
// 					}
// 					break;

// 				case HID_SET_REPORT:
// 					{
// 						// printf("wvh=%d\r\n", (uint16_t)UsbSetupBuf->wValueH);
// 						if (UsbSetupBuf->wValueH == HID_REPORT_TYPE_OUTPUT_REPORT)
// 						{
// 							switch (UsbSetupBuf->wValueL)
// 							{
// 								case REPORT_ID_CUBER_CMD:
// 									break;

// 								default:
// 									bRet = false;
// 									break;
// 							}
// 						}
// 						else if (UsbSetupBuf->wValueH == HID_REPORT_TYPE_FEATURE_REPORT)
// 						{
// 							// printf("wvl=%d\r\n", (uint16_t)UsbSetupBuf->wValueL);
// 							switch (UsbSetupBuf->wValueL)
// 							{
// 								case REPORT_ID_DEVICE_MODE:
// 									break;

// 								default:
// 									bRet = false;
// 									break;
// 							}
// 						}
						
						
// 					}
// 					break;

// 				case HID_SET_IDLE:
// 					// printf("HID_SET_IDLE = %d\r\n", u16ReqLen);
// 					break;

// 				default:
// 					bRet = false;
// 					break;
// 			}
// 		}
// 		else
// 		{
// 			// printf("bRequest1 = %d\r\n", (uint16_t)u8bRequest);
// 			switch (u8bRequest)
// 			{
// 			case USB_GET_DESCRIPTOR:
// 				{
// 					// printf("wValueH = %d\r\n", (uint16_t)UsbSetupBuf->wValueH);
// 					switch (UsbSetupBuf->wValueH)
// 					{
// 						case USB_DESCR_TYP_DEVICE:
// 							pEp0Data= (uint8_t *)DeviceDescriptor;
// 							u16Len = USB_DEVICE_DESC_SIZE;
// 							break;
// 						case USB_DESC_TYPE_CONFIGURATION:
// 							pEp0Data= (uint8_t *)ConfigDescriptor;
// 							u16Len = USB_CONFIGUARTION_DESC_TOTAL_SIZE;
// 							// printf("u16Len = %d\r\n", u16Len);
// 							break;

// 						case USB_DESCR_TYP_STRING:
// 							switch(UsbSetupBuf->wValueL)
// 							{
// 								case USB_STR_LANGUAGE_IDX:
// 									pEp0Data = (uint8_t *)StringLanguageDescriptor;
// 									u16Len = USB_STR_LANGUAGE_DESC_SIZE;
// 									break;
								
// 								case USB_STR_MANUFACTURER_IDX:
// 									pEp0Data = (uint8_t *)StringManufacturerDescriptor;
// 									u16Len = USB_STR_MANUFACTURER_DESC_SIZE;
// 									break;
								
// 								case USB_STR_PRODUCT_IDX:
// 									pEp0Data = (uint8_t *)StringProductDescriptor;
// 									u16Len = USB_STR_PRODUCT_DESC_SIZE;
// 									break;
								
// 								default:
// 									bRet = FALSE;
// 									break;
// 							}	  
// 							break;

// 						case USB_DESCR_TYP_REPORT:
// 							// printf("USB_DESCR_TYP_REPORT\r\n");
// 							pEp0Data = (uint8_t*)HidReportDescriptor;
// 							u16Len = USB_HID_REPORT_SIZE;
// 							// printf("u16Len = %d\r\n", (uint16_t)u16Len);
// 							break;

// 						default:
// 							bRet = false;
// 							break;
// 					}
// 				}
// 				break;

// 			case USB_SET_ADDRESS:
// 				UsbDeviceAddr = UsbSetupBuf->wValueL;
// 				break;

// 			case USB_SET_CONFIGURATION:
// 				bIsUsbConnected = true;
// 				// printf("USB_SET_CONFIGURATION\r\n");
// 				break;

// 			case USB_SET_INTERFACE:
// 				break;
			
// 			default:
// 				bRet = false;
// 				break;
// 			}
// 		}

// 	}
// 	else
// 	{
// 		bRet = false;
// 	}

// 	if (bRet == false)
// 	{
// 		UsbEp0Stall();
// 	}
// 	else 
// 	{
// 		if (u16Len != 0)
// 		{
// 			uint16_t PackageLen;
// 			u16Ep0RemainLen = (u16ReqLen < u16Len) ? u16ReqLen : u16Len;
// 			PackageLen = u16Ep0RemainLen >= THIS_ENDP0_SIZE ? THIS_ENDP0_SIZE : u16Ep0RemainLen;
// 			memcpy(Ep0Buffer, pEp0Data, PackageLen);
// 			pEp0Data += PackageLen;
// 			u16Ep0RemainLen -= PackageLen;
// 			UEP0_T_LEN = PackageLen;
// 			UEP0_CTRL = bUEP_R_TOG | bUEP_T_TOG | UEP_R_RES_ACK | UEP_T_RES_ACK;						//默认数据包是DATA1，返回应答ACK
// 		}
// 		else
// 		{
// 			UEP0_T_LEN = 0;																				//虽然尚未到状态阶段，但是提前预置上传0长度数据包以防主机提前进入状态阶段
// 			UEP0_CTRL = bUEP_R_TOG | bUEP_T_TOG | UEP_R_RES_ACK | UEP_T_RES_ACK;						//默认数据包是DATA1，返回应答ACK
// 		}
// 	}
// }

// static void UsbEp0In(void)
// {
// 	uint16_t u16PackageLen;
// 	// printf("bRequest = %d\r\n", (uint16_t)u8bRequest);
// 	switch (u8bRequest)
// 	{
// 		case USB_GET_DESCRIPTOR:
// 			u16PackageLen = u16Ep0RemainLen >= THIS_ENDP0_SIZE ? THIS_ENDP0_SIZE : u16Ep0RemainLen;
// 			memcpy(Ep0Buffer, pEp0Data, u16PackageLen);
// 			pEp0Data += u16PackageLen;
// 			u16Ep0RemainLen -= u16PackageLen;
// 			UEP0_T_LEN = u16PackageLen;
// 			UEP0_CTRL ^= bUEP_T_TOG;																	//同步标志位翻转
// 			// printf("Remain1 = %d\r\n", (uint16_t)u16Ep0RemainLen);
// 			break;
// 		case USB_SET_ADDRESS:
// 			// printf("USB_SET_ADDRESS\r\n");
// 			USB_DEV_AD = USB_DEV_AD & bUDA_GP_BIT | UsbDeviceAddr;
// 			UEP0_CTRL = UEP_R_RES_ACK | UEP_T_RES_NAK;
// 			break;

// 		default:
// 			UEP0_T_LEN = 0;																				//状态阶段完成中断或者是强制上传0长度数据包结束控制传输
// 			UEP0_CTRL = UEP_R_RES_ACK | UEP_T_RES_NAK;
// 			break;
// 	}
// }

// static void UsbEp0Out(void)
// {
// 	uint16_t u16Len = USB_RX_LEN;
// 	if (U_TOG_OK)
// 	{
// 		if(u8bRequest == HID_SET_REPORT)
// 		{
// 			memcpy(DataBuffer, Ep0Buffer, u16Len);
// 			switch (DataBuffer[0])
// 			{
// 			case REPORT_ID_DEVICE_MODE:
// 				// printf("REPORT_ID_DEVICE_MODE\r\n");
// 				break;

// 			case REPORT_ID_CUBER_CMD:
// 				memcpy((uint8_t *)&HidIfCtx, DataBuffer, u16Len);
// 				UsbRecFlag |= USB_SET_OUTPUT_REPORT;
// 				break;
			
// 			default:
// 				break;
// 			}
// 		}
// 		UEP0_CTRL ^= bUEP_R_TOG;                                     //同步标志位翻转	
// 	}
// }

// static void UsbEp0Stall(void)
// {
// 	UEP0_CTRL = bUEP_R_TOG | bUEP_T_TOG | UEP_R_RES_STALL | UEP_T_RES_STALL;			//STALL
// }

// static void UsbEp1In(void)
// {
// 	UEP1_T_LEN = 0;                                                     //预使用发送长度一定要清空
// 	//UEP2_CTRL ^= bUEP_T_TOG;                                          //如果不设置自动翻转则需要手动翻转
// 	UEP1_CTRL = UEP1_CTRL & ~ MASK_UEP_T_RES | UEP_T_RES_NAK;           //默认应答NAK
// }