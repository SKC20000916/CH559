#ifndef _LCD_H__
#define _LCD_H__

#include "Includes.h"

sbit LCD_RST = P0^2;
sbit LCD_RS = P0^3;

sbit LCD_BL = P1^2;
sbit LCD_CS = P1^4;
sbit LCD_SDA = P1^5;
sbit LCD_SCL = P1^7;

#define bLCD_RST		(1 << 2)
#define bLCD_RS			(1 << 3)

#define bLCD_BL			(1 << 2)
#define bLCD_CS			(1 << 4)
#define bLCD_SDA		(1 << 5)
#define bLCD_SCL		(1 << 7)

#define LCD_RST_L		(LCD_RST = 0)
#define LCD_RST_H		(LCD_RST = 1)

#define LCD_RS_L		(LCD_RS = 0)
#define LCD_RS_H		(LCD_RS = 1)

#define LCD_BL_OFF		(LCD_BL = 0)
#define LCD_BL_ON		(LCD_BL = 1)

#define LCD_CS_L		(LCD_CS = 0)
#define LCD_CS_H		(LCD_CS = 1)

#define LCD_SDA_L		(LCD_SDA = 0)
#define LCD_SDA_H		(LCD_SDA = 1)

#define LCD_SCL_L		(LCD_SCL = 0)
#define LCD_SCL_H		(LCD_SCL = 1)

#define USE_HORIZONTAL	(0)

void InitGPIO_LCD();
void LCD_WriteByte(u8 byte);
void LCD_WriteReg(u8 byte);
void LCD_WriteData(u16 dat);


//画笔颜色
#define WHITE         	 0xFFFF
#define BLACK         	 0x0000	  
#define BLUE           	 0x001F  
#define BRED             0XF81F
#define GRED 			       0XFFE0
#define GBLUE			       0X07FF
#define RED           	 0xF800
#define MAGENTA       	 0xF81F
#define GREEN         	 0x07E0
#define CYAN          	 0x7FFF
#define YELLOW        	 0xFFE0
#define BROWN 			     0XBC40 //棕色
#define BRRED 			     0XFC07 //棕红色
#define GRAY  			     0X8430 //灰色
#define DARKBLUE      	 0X01CF	//深蓝色
#define LIGHTBLUE      	 0X7D7C	//浅蓝色  
#define GRAYBLUE       	 0X5458 //灰蓝色
#define LIGHTGREEN     	 0X841F //浅绿色
#define LGRAY 			     0XC618 //浅灰色(PANNEL),窗体背景色
#define LGRAYBLUE        0XA651 //浅灰蓝色(中间层颜色)
#define LBBLUE           0X2B12 //浅棕蓝色(选择条目的反色)


#endif

