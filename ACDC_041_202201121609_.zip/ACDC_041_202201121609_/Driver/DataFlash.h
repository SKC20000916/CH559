#ifndef _DATAFLASH_H__
#define _DATAFLASH_H__

#include "Includes.h"

UINT8	EraseBlock( UINT16 Addr );
UINT8	ProgWord( UINT16 Addr, UINT16 Data );
UINT8 EraseDataFlash(UINT16 Addr);
void WriteDataFlash(UINT16 Addr,PUINT8 buf,UINT16 len);


#endif