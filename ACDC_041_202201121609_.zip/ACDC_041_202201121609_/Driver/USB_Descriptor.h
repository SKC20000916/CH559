#ifndef _USB_DESCRIPTOR_H__
#define _USB_DESCRIPTOR_H__

#include "Includes.h"

// #define USB_VENDOR_ID                   (0x32D7)
// #define USB_PRODUCT_ID                  (0x0001)

// #define USB_STR_MANUFACTURER_DESC       "ACDC Co.,Ltd."
// #define USB_STR_PRODUCT_DESC            "ACDC Touch Input Device"

// #define REPORT_ID_CUBER_CMD				('c')   /*  99 = 0x63 */
// #define REPORT_ID_CUBER_DATA			('d')   /* 100 = 0x64 */
// #define REPORT_ID_MULTI_TOUCH               (0x54)  /*  0x54 */
// #define REPORT_ID_SINGLE_TOUCH              (0x55)
// #define REPORT_ID_MOUSE                     (0x56)

// #define MAX_CONTACT_POINTS					(10)

// /* Feature Report */
// #define REPORT_ID_MAX_CONTACT               (0x11)
// #define REPORT_ID_LATENCY_MODE              (0x12)
// #define REPORT_ID_DEVICE_MODE               (0x13)
// #define REPORT_ID_DEV_CERT_STAT             (0x44)  /* Device Certification Status Feature Report (for MS THQA blob) */

// /* Other Definitions */
// #define MAX_X_POS                           (32767) /* 0x7FF */
// #define MAX_Y_POS                           (32767) /* 0x7FF */
// #define MAX_SCREEN_LEN_X                    (5300)  /* 53 cm */
// #define MAX_SCREEN_LEN_Y                    (3000)  /* 30 cm */

// #define WBVAL(x)							(x & 0xFF), ((x >> 8) & 0xFF)

// /* Descriptor Types */
// #define USB_DESC_TYPE_DEVICE					1
// #define USB_DESC_TYPE_CONFIGURATION				2
// #define USB_DESC_TYPE_STRING					3
// #define USB_DESC_TYPE_INTERFACE					4
// #define USB_DESC_TYPE_ENDPOINT					5
// #define USB_DESC_TYPE_DEVICE_QUALIFIER			6
// #define USB_DESC_TYPE_OTHERSPEED_CONFIG			7

// /* USB Device Classes */
// #define USB_DEVICE_CLASS_RESERVED               0x00
// #define USB_DEVICE_CLASS_AUDIO                  0x01
// #define USB_DEVICE_CLASS_COMMUNICATIONS         0x02
// #define USB_DEVICE_CLASS_HUMAN_INTERFACE        0x03
// #define USB_DEVICE_CLASS_MONITOR                0x04
// #define USB_DEVICE_CLASS_PHYSICAL_INTERFACE     0x05
// #define USB_DEVICE_CLASS_POWER                  0x06
// #define USB_DEVICE_CLASS_PRINTER                0x07
// #define USB_DEVICE_CLASS_STORAGE                0x08
// #define USB_DEVICE_CLASS_HUB                    0x09
// #define USB_DEVICE_CLASS_VENDOR_SPECIFIC        0xFF

// #define USB_STR_LANGUAGE_IDX					0x00
// #define USB_STR_MANUFACTURER_IDX				0x01
// #define USB_STR_PRODUCT_IDX						0x02
// #define USB_STR_SERIALNUMBER					0x03
// #define USB_STR_CONFIGURATION					0x04
// #define USB_STR_INTERFACE						0x05


// #define USB_CONFIG_POWERED_MASK                 0xC0
// #define USB_CONFIG_BUS_POWERED                  0x80
// #define USB_CONFIG_SELF_POWERED                 0x40
// #define USB_CONFIG_REMOTE_WAKEUP                0x20
// #define USB_CONFIG_POWER_MA(mA)                 ((mA)/2)

// #define HID_REPORT_TYPE_INPUT_REPORT            0x1
// #define HID_REPORT_TYPE_OUTPUT_REPORT           0x2
// #define HID_REPORT_TYPE_FEATURE_REPORT          0x3

// /* HID Class Descriptor Types */
// #define HID_CLASS_DESC                          0x21
// #define HID_REPORT_DESC                         0x22
// #define HID_PHYSICAL_DESC                       0x23

// /* bEndpointAddress in Endpoint Descriptor */
// #define USB_ENDPOINT_DIRECTION_MASK             0x80
// #define USB_ENDPOINT_NUMBER_MASK                0x0f  /* in bEndpointAddress */
// #define USB_ENDPOINT_OUT(addr)                  ((addr) | 0x00)
// #define USB_ENDPOINT_IN(addr)                   ((addr) | 0x80)

// /* bmAttributes in Endpoint Descriptor */
// #define USB_ENDPOINT_TYPE_MASK                  0x03
// #define USB_ENDPOINT_TYPE_CONTROL               0x00
// #define USB_ENDPOINT_TYPE_ISOCHRONOUS           0x01
// #define USB_ENDPOINT_TYPE_BULK                  0x02
// #define USB_ENDPOINT_TYPE_INTERRUPT             0x03

// /* USB Standard Device Descriptor */
// typedef struct {
//     uint8_t     bLength;
//     uint8_t     bDescriptorType;
//     uint16_t    bcdUSB;
//     uint8_t     bDeviceClass;
//     uint8_t     bDeviceSubClass;
//     uint8_t     bDeviceProtocol;
//     uint8_t     bMaxPacketSize0;
//     uint16_t    idVendor;
//     uint16_t    idProduct;
//     uint16_t    bcdDevice;
//     uint8_t     iManufacturer;
//     uint8_t     iProduct;
//     uint8_t     iSerialNumber;
//     uint8_t     bNumConfigurations;
// } USB_DEVICE_DESCRIPTOR;

// /* USB Standard Configuration Descriptor */
// typedef struct {
//     uint8_t     bLength;
//     uint8_t     bDescriptorType;
//     uint16_t    wTotalLength;
//     uint8_t     bNumInterfaces;
//     uint8_t     bConfigurationValue;
//     uint8_t     iConfiguration;
//     uint8_t     bmAttributes;
//     uint8_t     bMaxPower;
// } USB_CONFIGURATION_DESCRIPTOR;

// /* USB Standard Interface Descriptor */
// typedef struct {
//     uint8_t     bLength;
//     uint8_t     bDescriptorType;
//     uint8_t     bInterfaceNumber;
//     uint8_t     bAlternateSetting;
//     uint8_t     bNumEndpoints;
//     uint8_t     bInterfaceClass;
//     uint8_t     bInterfaceSubClass;
//     uint8_t     bInterfaceProtocol;
//     uint8_t     iInterface;
// } USB_INTERFACE_DESCRIPTOR;

// typedef struct {
//     uint8_t     bLength;
//     uint8_t     bDescriptorType;
//     uint16_t    bcdHID;
//     uint8_t     bCountryCode;
//     uint8_t     bNumDescriptors;
//     uint8_t     bReportDescriptorType;
//     uint16_t    wReportDescriptorLength;
// } HID_CLASS_DESCRIPTOR;

// /* USB Standard Endpoint Descriptor */
// typedef struct {
//     uint8_t     bLength;
//     uint8_t     bDescriptorType;
//     uint8_t     bEndpointAddress;
//     uint8_t     bmAttributes;
//     uint16_t    wMaxPacketSize;
//     uint8_t     bInterval;
// } USB_ENDPOINT_DESCRIPTOR;

// #define USB_DEVICE_DESC_SIZE					sizeof(USB_DEVICE_DESCRIPTOR)
// #define USB_CONFIGUARTION_DESC_SIZE				sizeof(USB_CONFIGURATION_DESCRIPTOR)
// #define USB_INTERFACE_DESC_SIZE					sizeof(USB_INTERFACE_DESCRIPTOR)
// #define USB_HID_DESC_SIZE						sizeof(HID_CLASS_DESCRIPTOR)
// #define USB_ENDPOINT_DESC_SIZE					sizeof(USB_ENDPOINT_DESCRIPTOR)
// #define USB_CONFIGUARTION_DESC_TOTAL_SIZE		(USB_CONFIGUARTION_DESC_SIZE + USB_INTERFACE_DESC_SIZE + USB_HID_DESC_SIZE + USB_ENDPOINT_DESC_SIZE)
// #define USB_HID_REPORT_SIZE						(806)	//(806) 118
// #define USB_STR_LANGUAGE_DESC_SIZE				(4)
// #define USB_STR_MANUFACTURER_DESC_SIZE			(sizeof(USB_STR_MANUFACTURER_DESC) * sizeof(uint16_t))
// #define USB_STR_PRODUCT_DESC_SIZE				(sizeof(USB_STR_PRODUCT_DESC) * sizeof(uint16_t))


// extern const uint8_t code DeviceDescriptor[USB_DEVICE_DESC_SIZE];
// extern const uint8_t code ConfigDescriptor[USB_CONFIGUARTION_DESC_TOTAL_SIZE];
// extern const uint8_t code StringLanguageDescriptor[USB_STR_LANGUAGE_DESC_SIZE];
// extern const uint8_t code StringManufacturerDescriptor[USB_STR_MANUFACTURER_DESC_SIZE];
// extern const uint8_t code StringProductDescriptor[USB_STR_PRODUCT_DESC_SIZE];
// extern const uint8_t code THQA_blob[257];
// extern const uint8_t code HidReportDescriptor[USB_HID_REPORT_SIZE];

#endif