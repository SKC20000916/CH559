#ifndef _USB_H__
#define _USB_H__

#include "Includes.h"

// #define USB_SET_OUTPUT_REPORT		(1 << 0)

// typedef struct {
//     uint8_t seqNum;										/* sequence number is increased by host */
//     uint8_t dir;										/* direction, rd('r'=0x72), wr('w'=0x77) */
//     uint32_t addr;										/* 32bit address */
//     uint16_t len;										/* length */
// } HID_IF_CTX;

// extern bool bIsUsbConnected;

// void InitUSB_Device(void);
// bool UsbEp1SendBuf(uint8_t *pBuf, uint8_t len);


#endif
