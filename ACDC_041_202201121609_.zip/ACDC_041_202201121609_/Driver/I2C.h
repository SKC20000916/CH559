#ifndef _I2C_H__
#define _I2C_H__

#include "Includes.h"

sbit I2C_SDA 	= P2^7;
sbit I2C_SCL 	= P2^6;
sbit I2C_INT 	= P2^5;
sbit I2C_RESET 	= P2^4;

// typedef enum
// {
//     I2C_DMA_Trans_Busy 			= 0,
//     I2C_DMA_Trans_Free			= 1,
// }I2C_DMA_Trans_Status;

#define bI2C_SDA		(1 << 7)
#define bI2C_SCL		(1 << 6)
#define bI2C_INT		(1 << 5)
#define bI2C_RESET		(1 << 4)

#define I2C_SDA_H		I2C_SDA = 1
#define I2C_SDA_L		I2C_SDA = 0

#define I2C_SCL_H		I2C_SCL = 1
#define I2C_SCL_L		I2C_SCL = 0

#define I2C_ACK			0
#define I2C_NACK		1

extern bool bI2C_InterruptEnabled;
extern uint8_t I2C_SlaveAddr;

void InitGPIO_I2C(void);
void InitINT_I2C(void);
bool I2C_WriteData(uint8_t Addr, uint8_t *WriteData, uint16_t WriteLen);
bool I2C_ReadData(uint8_t Addr, uint8_t *ReadData, uint16_t ReadLen);
bool WaitI2CTransFinish(uint32_t WaitTime);

#endif

