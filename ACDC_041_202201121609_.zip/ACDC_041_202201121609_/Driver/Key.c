#include "Key.h"

void InitGPIO_Key()
{
	P0_5 = 1;
	P0_DIR &= ~bRIGHT_KEY;
	P0_PU |= bRIGHT_KEY;

	P0_6 = 1;
	P0_DIR &= ~bDOWNLOAD_KEY;
	P0_PU |= bDOWNLOAD_KEY;

	P0_7 = 1;
	P0_DIR &= ~bLEFT_KEY;
	P0_PU |= bLEFT_KEY;


}