
#include "LED.h"

void InitGPIO_LED(void)
{
	P3_DIR = P3_DIR | (1 << 6);
	P3_PU = P3_PU |	(1 << 6);

	LED0_OFF;
}

