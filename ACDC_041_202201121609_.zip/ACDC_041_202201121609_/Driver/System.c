#include "System.h"

void InitSystemClock(void)
{
	SAFE_MOD = 0x55;
	SAFE_MOD = 0xAA;

#if EXTERNAL_OSC_ENABLE
	CLOCK_CFG |= bOSC_EN_XT;
	DelayMsHW(10);
	CLOCK_CFG &= ~bOSC_EN_INT;
#endif

	PLL_CFG = 0x1C | 0xE0;					//12MHz * 0x1C(28) = 336MHz, 336MHz / 0xE0(7) = 46MHz

#if SYSTEM_FREQUENCY == 56000000	
	CLOCK_CFG = (CLOCK_CFG & ~MASK_SYS_CK_DIV) | 0x06;  // 56MHz	
#endif	

	SAFE_MOD = 0xFF;
}