#ifndef _LED_H__
#define _LED_H__

#include "Includes.h"

sbit LED_0 = P3^6;


#define LED0_ON		LED_0 = 0
#define LED0_OFF	LED_0 = 1

void InitGPIO_LED(void);


#endif
