#include "LCD.h"

void InitGPIO_LCD()
{
	P0_DIR = P0_DIR | (bLCD_RST | bLCD_RS);
	P1_DIR = P1_DIR | (bLCD_BL | bLCD_CS | bLCD_SDA | bLCD_SCL);

	LCD_BL_OFF;
}

void LCD_WriteData(u16 dat)
{
	LCD_WriteByte(dat >> 8);
	LCD_WriteByte(dat);
}

void LCD_WriteReg(u8 byte)
{
	LCD_RS_L;
	LCD_WriteByte(byte);
	LCD_RS_H;
}

void LCD_WriteByte(u8 byte) 
{	
	u8 i;
	LCD_CS_L;
	for(i = 0; i < 8; i++)
	{			  
		LCD_SCL_L;
		if(byte & 0x80)
		{
			LCD_SDA_H;
		}
		else
		{
			LCD_SDA_L;
		}
		LCD_SCL_H;
		byte <<= 1;
	}	
	LCD_CS_H;	
}