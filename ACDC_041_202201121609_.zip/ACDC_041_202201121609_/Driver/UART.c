#include "UART.h"

void InitUART0(void)
{
	uint16_t xdata count;
	SM0 = 0;										//UART0选择8位数据位
	SM1 = 1;	//UART								//可变波特率
	SM2 = 0;

	RCLK = 0;
    TCLK = 0;

	PCON |= SMOD;									//快速模式

	TMOD = TMOD & ~bT1_GATE & ~bT1_CT & ~MASK_T1_MOD | bT1_M1;
	T2MOD = T2MOD | bTMR_CLK | bT1_CLK;

	count = SYSTEM_FREQUENCY / UART0_BAUDRATE / 16;

	TH1 = 0 - count; 
    TR1 = 1; 
    TI = 1;

	PIN_FUNC &= ~bUART0_PIN_X;						//UART0 P3.0 P3.1
}

// void UART0_SendByte(uint8_t send_byte)
// {
// 	SBUF = send_byte;
// 	while(TI == 0);
// 	TI = 0;
// }

// char putchar(char c)
// {
// 	UART0_SendByte(c);
// 	return c;
// }