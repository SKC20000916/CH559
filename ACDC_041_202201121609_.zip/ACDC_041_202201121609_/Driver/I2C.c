#include "I2C.h"

static void I2C_Start(void);
static void I2C_Stop(void);
static void I2C_Ack(void);
static void I2C_NAck(void);
static uint8_t I2C_WriteByte(uint8_t byte);
static uint8_t I2C_ReadByte(uint8_t ack);


bool bI2C_InterruptEnabled = false;

void InitGPIO_I2C(void)
{
	P2_DIR = P2_DIR | (bI2C_SDA | bI2C_SCL | bI2C_INT | bI2C_RESET);
	P2_PU |= (bI2C_SDA | bI2C_SCL | bI2C_INT | bI2C_RESET);
}

// void InitINT_I2C(void)
// {
	// GPIO_IE |= bIE_IO_EDGE;														//上升/下降触发
	// GPIO_IE |= bIE_P1_3_LO;            
	// IE_GPIO = 1;                                                               //GPIO中断开启
// }

bool I2C_WriteData(uint8_t Addr, uint8_t *WriteData, uint16_t WriteLen)
{
	uint16_t xdata i;
	// printf("I2C_WriteData\r\n");
	I2C_Start();
	if (I2C_WriteByte(Addr) == I2C_NACK)
	{
		I2C_Stop();
		return false;
	}
	for (i = 0; i < WriteLen; i++)
	{
		if (I2C_WriteByte(*WriteData++) == I2C_NACK)
		{
			I2C_Stop();
			return false;
		}
	}
	I2C_Stop();
	return true;
}

bool I2C_ReadData(uint8_t Addr, uint8_t *ReadData, uint16_t ReadLen)
{
	uint16_t xdata i = 0;
	I2C_Start();
	if (I2C_WriteByte(Addr | 0x01) == I2C_NACK)
	{
		I2C_Stop();
		return false;
	}
	for (i = 0; i < ReadLen - 1; i++)
	{
		ReadData[i] = I2C_ReadByte(I2C_ACK);
	}
	ReadData[i] = I2C_ReadByte(I2C_NACK);
	I2C_Stop();
	return true;
}

static uint8_t I2C_ReadByte(uint8_t ack)
{
	uint8_t i = 0, Rec = 0;
	I2C_SDA_H;
	for(i = 0; i < 8; i++)
	{
		DelayUs(1);
		I2C_SCL_H;
		Rec <<= 1;
		if(I2C_SDA)
			Rec++;   
		DelayUs(1);
		I2C_SCL_L;		
	}     
	
	if (!ack)
		I2C_Ack();					//发送nACK
	else
		I2C_NAck();					//发送ACK   
	return Rec;
}

static uint8_t I2C_WriteByte(uint8_t byte)
{                        
	uint8_t i;   
	for(i = 0; i < 8; i++)
	{     
		I2C_SCL_L;          
		if (byte & 0x80)  
		{
			I2C_SDA_H;
		}
		else
		{
			I2C_SDA_L;
		}
		
		DelayUs(1);  
		I2C_SCL_H;
		byte <<= 1;    
		DelayUs(1);
	}  
	I2C_SCL_L; 
	I2C_SDA_H;
	DelayUs(1);    
	I2C_SCL_H;
	DelayUs(1);
	if (I2C_SDA)
	{
		I2C_SCL_L;
		// DelayUs(3);
		return I2C_NACK;
	}
	else
	{
		I2C_SCL_L;
		// DelayUs(3);
		return I2C_ACK;
	}
}

static void I2C_Start(void)     
{
	I2C_SDA_H;
	I2C_SCL_H;
	DelayUs(1);
	I2C_SDA_L;
	DelayUs(1);
	I2C_SCL_L;
	DelayUs(1);
}

static void I2C_Stop(void)
{
	I2C_SDA_L;
	I2C_SCL_L;
	DelayUs(1);
	I2C_SCL_H;
	DelayUs(1);
	I2C_SDA_H;
	DelayUs(1);
}


static void I2C_Ack(void)//这两个的延时不能降了
{
	I2C_SCL_L;
	I2C_SDA_L;
	DelayUs(4);
	I2C_SCL_H;
	DelayUs(4);
	I2C_SCL_L;
}

static void I2C_NAck(void)
{
	I2C_SCL_L;
	I2C_SDA_H;
	DelayUs(4);
	I2C_SCL_H;
	DelayUs(4);
	I2C_SCL_L;
}


void GPIOInterrupt(void) interrupt INT_NO_GPIO using 2													//GPIO中断服务程序,使用寄存器组1
{
	bI2C_InterruptEnabled = true;
}