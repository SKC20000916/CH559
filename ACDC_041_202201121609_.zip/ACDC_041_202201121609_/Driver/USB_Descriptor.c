#include "USB_Descriptor.h"

// const uint8_t code DeviceDescriptor[USB_DEVICE_DESC_SIZE] = {
//     USB_DEVICE_DESC_SIZE,                   /* bLength */
//     USB_DESC_TYPE_DEVICE,                   /* bDescriptorType */
//     WBVAL(0x0110), /* 1.10 */               /* bcdUSB, The bcdUSB field indicates the version of the USB specification to which the device conforms. */
//     0x00,                                   /* bDeviceClass */
//     0x00,                                   /* bDeviceSubClass */
//     0x00,                                   /* bDeviceProtocol */
//     MAX_PACKET_SIZE,             			/* bMaxPacketSize0 */
//     WBVAL(USB_VENDOR_ID),                   /* idVendor */
//     WBVAL(USB_PRODUCT_ID),                  /* idProduct */
//     WBVAL(0x0200),							/* bcdDevice */
// 	USB_STR_MANUFACTURER_IDX,               /* iManufacturer - index of manufacturer desc. */
// 	USB_STR_PRODUCT_IDX,                    /* iProduct - index of product desc. */
//     0x00,                                   /* iSerialNumber - index of serial desc. */
//     0x01                                    /* bNumConfigurations */
// };

// const uint8_t code ConfigDescriptor[USB_CONFIGUARTION_DESC_TOTAL_SIZE] = {
//     /* Configuration 1 */
//     USB_CONFIGUARTION_DESC_SIZE,                        /* bLength */
//     USB_DESC_TYPE_CONFIGURATION,                        /* bDescriptorType */
//     WBVAL(USB_CONFIGUARTION_DESC_TOTAL_SIZE),           /* wTotalLength */
//     0x01,                                               /* bNumInterfaces */
//     0x01,                                               /* bConfigurationValue */
//     0x00,                                               /* iConfiguration */
//     USB_CONFIG_BUS_POWERED | USB_CONFIG_REMOTE_WAKEUP,  /* bmAttributes */
//     USB_CONFIG_POWER_MA(98),                            /* bMaxPower */

//     /* Interface 0, Alternate Setting 0, HID Class */
//     USB_INTERFACE_DESC_SIZE,                            /* bLength */
//     USB_DESC_TYPE_INTERFACE,                            /* bDescriptorType */
//     0x00,                                               /* bInterfaceNumber */
//     0x00,                                               /* bAlternateSetting */

//     0x01,                                               /* bNumEndpoints */
//     USB_DEVICE_CLASS_HUMAN_INTERFACE,                   /* bInterfaceClass */
//     0,                                                  /* bInterfaceSubClass */
//     0,                                                  /* bInterfaceProtocol */
//     0,                                                  /* iInterface */

//     /* HID Class-Specific Descriptor */
//     USB_HID_DESC_SIZE,                                  /* bLength */
//     HID_CLASS_DESC,                                     /* bDescriptorType */
//     WBVAL(0x0112), /* 1.12 */                           /* bcdHID_Spec_Release_Number */
//     0x00,                                               /* Country Code (0x00 for Not supported) */
//     0x01,                                               /* bNumClassDescriptor */
//     HID_REPORT_DESC,                                    /* bReportDescriptorType = HID */
//     WBVAL(USB_HID_REPORT_SIZE),                         /* wReportDescriptorLength */

//     /* INTR In Endpoint */
//     USB_ENDPOINT_DESC_SIZE,                             /* bLength */
//     USB_DESC_TYPE_ENDPOINT,                             /* bDescriptorType */
//     USB_ENDPOINT_IN(1),                                 /* bEndpointAddress */
//     USB_ENDPOINT_TYPE_INTERRUPT,                        /* bmAttributes */
//     WBVAL(0x0040),                                      /* wMaxPacketSize  = 64byte */
//     1,                        							/* for LS/FS, bInterval in ms units */
// };

// const uint8_t code StringLanguageDescriptor[USB_STR_LANGUAGE_DESC_SIZE] = {
//     USB_STR_LANGUAGE_DESC_SIZE, /* bLength */
//     USB_DESC_TYPE_STRING,       /* bDescriptorType */
//     WBVAL(0x0409),              /* wLANGID - US English */
// };

// const uint8_t code StringManufacturerDescriptor[USB_STR_MANUFACTURER_DESC_SIZE] = {    
//     USB_STR_MANUFACTURER_DESC_SIZE,         /* bLength */
//     USB_DESC_TYPE_STRING,					/* bDescriptorType */
//     'A', 0,
//     'C', 0,
//     'D', 0,
//     'C', 0,
//     ' ', 0,
//     'C', 0,
//     'o', 0,
//     '.', 0,
//     ',', 0,
//     'L', 0,
//     't', 0,
//     'd', 0,
//     '.', 0
// };

// const uint8_t code StringProductDescriptor[USB_STR_PRODUCT_DESC_SIZE] = {
//     USB_STR_PRODUCT_DESC_SIZE,              /* bLength */
//     USB_DESC_TYPE_STRING,					/* bDescriptorType */
//     'A', 0,
//     'C', 0,
//     'D', 0,
//     'C', 0,
//     ' ', 0,
//     'T', 0,
//     'o', 0,
//     'u', 0,
//     'c', 0,
//     'h', 0,
//     ' ', 0,
//     'I', 0,
//     'n', 0,
//     'p', 0,
//     'u', 0,
//     't', 0,
//     ' ', 0,
//     'D', 0,
// 	'e', 0,
// 	'v', 0,
// 	'i', 0,
// 	'c', 0,
// 	'e', 0,
// };

// const uint8_t code THQA_blob[257] = {
//     REPORT_ID_DEV_CERT_STAT,
//     0xfc, 0x28, 0xfe, 0x84, 0x40, 0xcb, 0x9a, 0x87, 0x0d, 0xbe, 0x57, 0x3c, 0xb6, 0x70, 0x09, 0x88,
//     0x07, 0x97, 0x2d, 0x2b, 0xe3, 0x38, 0x34, 0xb6, 0x6c, 0xed, 0xb0, 0xf7, 0xe5, 0x9c, 0xf6, 0xc2,
//     0x2e, 0x84, 0x1b, 0xe8, 0xb4, 0x51, 0x78, 0x43, 0x1f, 0x28, 0x4b, 0x7c, 0x2d, 0x53, 0xaf, 0xfc,
//     0x47, 0x70, 0x1b, 0x59, 0x6f, 0x74, 0x43, 0xc4, 0xf3, 0x47, 0x18, 0x53, 0x1a, 0xa2, 0xa1, 0x71,
//     0xc7, 0x95, 0x0e, 0x31, 0x55, 0x21, 0xd3, 0xb5, 0x1e, 0xe9, 0x0c, 0xba, 0xec, 0xb8, 0x89, 0x19,
//     0x3e, 0xb3, 0xaf, 0x75, 0x81, 0x9d, 0x53, 0xb9, 0x41, 0x57, 0xf4, 0x6d, 0x39, 0x25, 0x29, 0x7c,
//     0x87, 0xd9, 0xb4, 0x98, 0x45, 0x7d, 0xa7, 0x26, 0x9c, 0x65, 0x3b, 0x85, 0x68, 0x89, 0xd7, 0x3b,
//     0xbd, 0xff, 0x14, 0x67, 0xf2, 0x2b, 0xf0, 0x2a, 0x41, 0x54, 0xf0, 0xfd, 0x2c, 0x66, 0x7c, 0xf8,
//     0xc0, 0x8f, 0x33, 0x13, 0x03, 0xf1, 0xd3, 0xc1, 0x0b, 0x89, 0xd9, 0x1b, 0x62, 0xcd, 0x51, 0xb7,
//     0x80, 0xb8, 0xaf, 0x3a, 0x10, 0xc1, 0x8a, 0x5b, 0xe8, 0x8a, 0x56, 0xf0, 0x8c, 0xaa, 0xfa, 0x35,
//     0xe9, 0x42, 0xc4, 0xd8, 0x55, 0xc3, 0x38, 0xcc, 0x2b, 0x53, 0x5c, 0x69, 0x52, 0xd5, 0xc8, 0x73,
//     0x02, 0x38, 0x7c, 0x73, 0xb6, 0x41, 0xe7, 0xff, 0x05, 0xd8, 0x2b, 0x79, 0x9a, 0xe2, 0x34, 0x60,
//     0x8f, 0xa3, 0x32, 0x1f, 0x09, 0x78, 0x62, 0xbc, 0x80, 0xe3, 0x0f, 0xbd, 0x65, 0x20, 0x08, 0x13,
//     0xc1, 0xe2, 0xee, 0x53, 0x2d, 0x86, 0x7e, 0xa7, 0x5a, 0xc5, 0xd3, 0x7d, 0x98, 0xbe, 0x31, 0x48,
//     0x1f, 0xfb, 0xda, 0xaf, 0xa2, 0xa8, 0x6a, 0x89, 0xd6, 0xbf, 0xf2, 0xd3, 0x32, 0x2a, 0x9a, 0xe4,
//     0xcf, 0x17, 0xb7, 0xb8, 0xf4, 0xe1, 0x33, 0x08, 0x24, 0x8b, 0xc4, 0x43, 0xa5, 0xe5, 0x24, 0xc2
// };

// const uint8_t code HidReportDescriptor[USB_HID_REPORT_SIZE] = {

// #if 1
//     /* Multi-Touch Input Report (Hybrid mode)  8 byte*/
//     0x05, 0x0d,                    // USAGE_PAGE (Digitizers)
//     0x09, 0x04,                    // USAGE (Touch Screen)
//     0xa1, 0x01,                    // COLLECTION (Application)
//     0x85, REPORT_ID_MULTI_TOUCH,   //   REPORT_ID ('T' = 0x54 = 84)

//     /* finger#0 - 61 bytes */
//     0x09, 0x22,                    //   USAGE (Finger #0)
//     0xa1, 0x02,                    //   COLLECTION (Logical)
//     0x09, 0x42,                    //     USAGE (Tip Switch)
//     0x15, 0x00,                    //     LOGICAL_MINIMUM (0)
//     0x25, 0x01,                    //     LOGICAL_MAXIMUM (1)
//     0x75, 0x01,                    //     REPORT_SIZE (1)
//     0x95, 0x01,                    //     REPORT_COUNT (1)
//     0x81, 0x02,                    //     INPUT (Data,Var,Abs)
//     0x95, 0x07,                    //     REPORT_COUNT (7)
//     0x81, 0x03,                    //     INPUT (Cnst,Var,Abs)
//     0x09, 0x51,                    //     USAGE (Contact identifier)
//     0x75, 0x08,                    //     REPORT_SIZE (8)
//     0x95, 0x01,                    //     REPORT_COUNT (1)
//     0x81, 0x02,                    //     INPUT (Data,Var,Abs)
//     0x05, 0x01,                    //     USAGE_PAGE (Generic Desktop)
//     0x75, 0x10,                    //     REPORT_SIZE (16)
//     0x55, 0x0e,                    //     UNIT_EXPONENT (-2)
//     0x65, 0x11,                    //     UNIT (SI Lin:Distance)
//     0x15, 0x00,                    //     LOGICAL_MINIMUM (0)
//     0x35, 0x00,                    //     PHYSICAL_MINIMUM (0)
//     0x09, 0x30,                    //     USAGE (X)
//     0x26, WBVAL(MAX_X_POS),        //     LOGICAL_MAXIMUM (0x7FFF = 32767)
//     0x46, WBVAL(MAX_SCREEN_LEN_X), //     PHYSICAL_MAXIMUM (0x14b4 = 5300)
//     0x81, 0x02,                    //     INPUT (Data,Var,Abs)
//     0x09, 0x31,                    //     USAGE (Y)
//     0x26, WBVAL(MAX_Y_POS),        //     LOGICAL_MAXIMUM (0x7FFF = 32767)
//     0x46, WBVAL(MAX_SCREEN_LEN_Y), //     PHYSICAL_MAXIMUM (0x0bb8 = 3000)
//     0x81, 0x02,                    //     INPUT (Data,Var,Abs)
//     0xc0,                          //   END_COLLECTION

//     /* finger#1 - 63 bytes */
//     0x05, 0x0d,                    //   USAGE_PAGE (Digitizers)
//     0x09, 0x22,                    //   USAGE (Finger #1)
//     0xa1, 0x02,                    //   COLLECTION (Logical)
//     0x09, 0x42,                    //     USAGE (Tip Switch)
//     0x15, 0x00,                    //     LOGICAL_MINIMUM (0)
//     0x25, 0x01,                    //     LOGICAL_MAXIMUM (1)
//     0x75, 0x01,                    //     REPORT_SIZE (1)
//     0x95, 0x01,                    //     REPORT_COUNT (1)
//     0x81, 0x02,                    //     INPUT (Data,Var,Abs)
//     0x95, 0x07,                    //     REPORT_COUNT (7)
//     0x81, 0x03,                    //     INPUT (Cnst,Var,Abs)
//     0x09, 0x51,                    //     USAGE (Contact identifier)
//     0x75, 0x08,                    //     REPORT_SIZE (8)
//     0x95, 0x01,                    //     REPORT_COUNT (1)
//     0x81, 0x02,                    //     INPUT (Data,Var,Abs)
//     0x05, 0x01,                    //     USAGE_PAGE (Generic Desktop)
//     0x75, 0x10,                    //     REPORT_SIZE (16)
//     0x55, 0x0e,                    //     UNIT_EXPONENT (-2)
//     0x65, 0x11,                    //     UNIT (SI Lin:Distance)
//     0x15, 0x00,                    //     LOGICAL_MINIMUM (0)
//     0x35, 0x00,                    //     PHYSICAL_MINIMUM (0)
//     0x09, 0x30,                    //     USAGE (X)
//     0x26, WBVAL(MAX_X_POS),        //     LOGICAL_MAXIMUM (0x7FFF = 32767)
//     0x46, WBVAL(MAX_SCREEN_LEN_X), //     PHYSICAL_MAXIMUM (0x14b4 = 5300)
//     0x81, 0x02,                    //     INPUT (Data,Var,Abs)
//     0x09, 0x31,                    //     USAGE (Y)
//     0x26, WBVAL(MAX_Y_POS),        //     LOGICAL_MAXIMUM (0x7FFF = 32767)
//     0x46, WBVAL(MAX_SCREEN_LEN_Y), //     PHYSICAL_MAXIMUM (0x0bb8 = 3000)
//     0x81, 0x02,                    //     INPUT (Data,Var,Abs)
//     0xc0,                          //   END_COLLECTION

//     /* finger#2 - 63 bytes */
//     0x05, 0x0d,                    //   USAGE_PAGE (Digitizers)
//     0x09, 0x22,                    //   USAGE (Finger #2)
//     0xa1, 0x02,                    //   COLLECTION (Logical)
//     0x09, 0x42,                    //     USAGE (Tip Switch)
//     0x15, 0x00,                    //     LOGICAL_MINIMUM (0)
//     0x25, 0x01,                    //     LOGICAL_MAXIMUM (1)
//     0x75, 0x01,                    //     REPORT_SIZE (1)
//     0x95, 0x01,                    //     REPORT_COUNT (1)
//     0x81, 0x02,                    //     INPUT (Data,Var,Abs)
//     0x95, 0x07,                    //     REPORT_COUNT (7)
//     0x81, 0x03,                    //     INPUT (Cnst,Var,Abs)
//     0x09, 0x51,                    //     USAGE (Contact identifier)
//     0x75, 0x08,                    //     REPORT_SIZE (8)
//     0x95, 0x01,                    //     REPORT_COUNT (1)
//     0x81, 0x02,                    //     INPUT (Data,Var,Abs)
//     0x05, 0x01,                    //     USAGE_PAGE (Generic Desktop)
//     0x75, 0x10,                    //     REPORT_SIZE (16)
//     0x55, 0x0e,                    //     UNIT_EXPONENT (-2)
//     0x65, 0x11,                    //     UNIT (SI Lin:Distance)
//     0x15, 0x00,                    //     LOGICAL_MINIMUM (0)
//     0x35, 0x00,                    //     PHYSICAL_MINIMUM (0)
//     0x09, 0x30,                    //     USAGE (X)
//     0x26, WBVAL(MAX_X_POS),        //     LOGICAL_MAXIMUM (0x7FFF = 32767)
//     0x46, WBVAL(MAX_SCREEN_LEN_X), //     PHYSICAL_MAXIMUM (0x14b4 = 5300)
//     0x81, 0x02,                    //     INPUT (Data,Var,Abs)
//     0x09, 0x31,                    //     USAGE (Y)
//     0x26, WBVAL(MAX_Y_POS),        //     LOGICAL_MAXIMUM (0x7FFF = 32767)
//     0x46, WBVAL(MAX_SCREEN_LEN_Y), //     PHYSICAL_MAXIMUM (0x0bb8 = 3000)
//     0x81, 0x02,                    //     INPUT (Data,Var,Abs)
//     0xc0,                          //   END_COLLECTION

//     /* finger#3 - 63 bytes */
//     0x05, 0x0d,                    //   USAGE_PAGE (Digitizers)
//     0x09, 0x22,                    //   USAGE (Finger #3)
//     0xa1, 0x02,                    //   COLLECTION (Logical)
//     0x09, 0x42,                    //     USAGE (Tip Switch)
//     0x15, 0x00,                    //     LOGICAL_MINIMUM (0)
//     0x25, 0x01,                    //     LOGICAL_MAXIMUM (1)
//     0x75, 0x01,                    //     REPORT_SIZE (1)
//     0x95, 0x01,                    //     REPORT_COUNT (1)
//     0x81, 0x02,                    //     INPUT (Data,Var,Abs)
//     0x95, 0x07,                    //     REPORT_COUNT (7)
//     0x81, 0x03,                    //     INPUT (Cnst,Var,Abs)
//     0x09, 0x51,                    //     USAGE (Contact identifier)
//     0x75, 0x08,                    //     REPORT_SIZE (8)
//     0x95, 0x01,                    //     REPORT_COUNT (1)
//     0x81, 0x02,                    //     INPUT (Data,Var,Abs)
//     0x05, 0x01,                    //     USAGE_PAGE (Generic Desktop)
//     0x75, 0x10,                    //     REPORT_SIZE (16)
//     0x55, 0x0e,                    //     UNIT_EXPONENT (-2)
//     0x65, 0x11,                    //     UNIT (SI Lin:Distance)
//     0x15, 0x00,                    //     LOGICAL_MINIMUM (0)
//     0x35, 0x00,                    //     PHYSICAL_MINIMUM (0)
//     0x09, 0x30,                    //     USAGE (X)
//     0x26, WBVAL(MAX_X_POS),        //     LOGICAL_MAXIMUM (0x7FFF = 32767)
//     0x46, WBVAL(MAX_SCREEN_LEN_X), //     PHYSICAL_MAXIMUM (0x14b4 = 5300)
//     0x81, 0x02,                    //     INPUT (Data,Var,Abs)
//     0x09, 0x31,                    //     USAGE (Y)
//     0x26, WBVAL(MAX_Y_POS),        //     LOGICAL_MAXIMUM (0x7FFF = 32767)
//     0x46, WBVAL(MAX_SCREEN_LEN_Y), //     PHYSICAL_MAXIMUM (0x0bb8 = 3000)
//     0x81, 0x02,                    //     INPUT (Data,Var,Abs)
//     0xc0,                          //   END_COLLECTION

//     /* finger#4 - 63 bytes */
//     0x05, 0x0d,                    //   USAGE_PAGE (Digitizers)
//     0x09, 0x22,                    //   USAGE (Finger #4)
//     0xa1, 0x02,                    //   COLLECTION (Logical)
//     0x09, 0x42,                    //     USAGE (Tip Switch)
//     0x15, 0x00,                    //     LOGICAL_MINIMUM (0)
//     0x25, 0x01,                    //     LOGICAL_MAXIMUM (1)
//     0x75, 0x01,                    //     REPORT_SIZE (1)
//     0x95, 0x01,                    //     REPORT_COUNT (1)
//     0x81, 0x02,                    //     INPUT (Data,Var,Abs)
//     0x95, 0x07,                    //     REPORT_COUNT (7)
//     0x81, 0x03,                    //     INPUT (Cnst,Var,Abs)
//     0x09, 0x51,                    //     USAGE (Contact identifier)
//     0x75, 0x08,                    //     REPORT_SIZE (8)
//     0x95, 0x01,                    //     REPORT_COUNT (1)
//     0x81, 0x02,                    //     INPUT (Data,Var,Abs)
//     0x05, 0x01,                    //     USAGE_PAGE (Generic Desktop)
//     0x75, 0x10,                    //     REPORT_SIZE (16)
//     0x55, 0x0e,                    //     UNIT_EXPONENT (-2)
//     0x65, 0x11,                    //     UNIT (SI Lin:Distance)
//     0x15, 0x00,                    //     LOGICAL_MINIMUM (0)
//     0x35, 0x00,                    //     PHYSICAL_MINIMUM (0)
//     0x09, 0x30,                    //     USAGE (X)
//     0x26, WBVAL(MAX_X_POS),        //     LOGICAL_MAXIMUM (0x7FFF = 32767)
//     0x46, WBVAL(MAX_SCREEN_LEN_X), //     PHYSICAL_MAXIMUM (0x14b4 = 5300)
//     0x81, 0x02,                    //     INPUT (Data,Var,Abs)
//     0x09, 0x31,                    //     USAGE (Y)
//     0x26, WBVAL(MAX_Y_POS),        //     LOGICAL_MAXIMUM (0x7FFF = 32767)
//     0x46, WBVAL(MAX_SCREEN_LEN_Y), //     PHYSICAL_MAXIMUM (0x0bb8 = 3000)
//     0x81, 0x02,                    //     INPUT (Data,Var,Abs)
//     0xc0,                          //   END_COLLECTION

//     /* finger#5 - 63 bytes */
//     0x05, 0x0d,                    //   USAGE_PAGE (Digitizers)
//     0x09, 0x22,                    //   USAGE (Finger #5)
//     0xa1, 0x02,                    //   COLLECTION (Logical)
//     0x09, 0x42,                    //     USAGE (Tip Switch)
//     0x15, 0x00,                    //     LOGICAL_MINIMUM (0)
//     0x25, 0x01,                    //     LOGICAL_MAXIMUM (1)
//     0x75, 0x01,                    //     REPORT_SIZE (1)
//     0x95, 0x01,                    //     REPORT_COUNT (1)
//     0x81, 0x02,                    //     INPUT (Data,Var,Abs)
//     0x95, 0x07,                    //     REPORT_COUNT (7)
//     0x81, 0x03,                    //     INPUT (Cnst,Var,Abs)
//     0x09, 0x51,                    //     USAGE (Contact identifier)
//     0x75, 0x08,                    //     REPORT_SIZE (8)
//     0x95, 0x01,                    //     REPORT_COUNT (1)
//     0x81, 0x02,                    //     INPUT (Data,Var,Abs)
//     0x05, 0x01,                    //     USAGE_PAGE (Generic Desktop)
//     0x75, 0x10,                    //     REPORT_SIZE (16)
//     0x55, 0x0e,                    //     UNIT_EXPONENT (-2)
//     0x65, 0x11,                    //     UNIT (SI Lin:Distance)
//     0x15, 0x00,                    //     LOGICAL_MINIMUM (0)
//     0x35, 0x00,                    //     PHYSICAL_MINIMUM (0)
//     0x09, 0x30,                    //     USAGE (X)
//     0x26, WBVAL(MAX_X_POS),        //     LOGICAL_MAXIMUM (0x7FFF = 32767)
//     0x46, WBVAL(MAX_SCREEN_LEN_X), //     PHYSICAL_MAXIMUM (0x14b4 = 5300)
//     0x81, 0x02,                    //     INPUT (Data,Var,Abs)
//     0x09, 0x31,                    //     USAGE (Y)
//     0x26, WBVAL(MAX_Y_POS),        //     LOGICAL_MAXIMUM (0x7FFF = 32767)
//     0x46, WBVAL(MAX_SCREEN_LEN_Y), //     PHYSICAL_MAXIMUM (0x0bb8 = 3000)
//     0x81, 0x02,                    //     INPUT (Data,Var,Abs)
//     0xc0,                          //   END_COLLECTION

//     /* finger#6 - 63 bytes */
//     0x05, 0x0d,                    //   USAGE_PAGE (Digitizers)
//     0x09, 0x22,                    //   USAGE (Finger #6)
//     0xa1, 0x02,                    //   COLLECTION (Logical)
//     0x09, 0x42,                    //     USAGE (Tip Switch)
//     0x15, 0x00,                    //     LOGICAL_MINIMUM (0)
//     0x25, 0x01,                    //     LOGICAL_MAXIMUM (1)
//     0x75, 0x01,                    //     REPORT_SIZE (1)
//     0x95, 0x01,                    //     REPORT_COUNT (1)
//     0x81, 0x02,                    //     INPUT (Data,Var,Abs)
//     0x95, 0x07,                    //     REPORT_COUNT (7)
//     0x81, 0x03,                    //     INPUT (Cnst,Var,Abs)
//     0x09, 0x51,                    //     USAGE (Contact identifier)
//     0x75, 0x08,                    //     REPORT_SIZE (8)
//     0x95, 0x01,                    //     REPORT_COUNT (1)
//     0x81, 0x02,                    //     INPUT (Data,Var,Abs)
//     0x05, 0x01,                    //     USAGE_PAGE (Generic Desktop)
//     0x75, 0x10,                    //     REPORT_SIZE (16)
//     0x55, 0x0e,                    //     UNIT_EXPONENT (-2)
//     0x65, 0x11,                    //     UNIT (SI Lin:Distance)
//     0x15, 0x00,                    //     LOGICAL_MINIMUM (0)
//     0x35, 0x00,                    //     PHYSICAL_MINIMUM (0)
//     0x09, 0x30,                    //     USAGE (X)
//     0x26, WBVAL(MAX_X_POS),        //     LOGICAL_MAXIMUM (0x7FFF = 32767)
//     0x46, WBVAL(MAX_SCREEN_LEN_X), //     PHYSICAL_MAXIMUM (0x14b4 = 5300)
//     0x81, 0x02,                    //     INPUT (Data,Var,Abs)
//     0x09, 0x31,                    //     USAGE (Y)
//     0x26, WBVAL(MAX_Y_POS),        //     LOGICAL_MAXIMUM (0x7FFF = 32767)
//     0x46, WBVAL(MAX_SCREEN_LEN_Y), //     PHYSICAL_MAXIMUM (0x0bb8 = 3000)
//     0x81, 0x02,                    //     INPUT (Data,Var,Abs)
//     0xc0,                          //   END_COLLECTION

//     /* finger#7 - 63 bytes */
//     0x05, 0x0d,                    //   USAGE_PAGE (Digitizers)
//     0x09, 0x22,                    //   USAGE (Finger #7)
//     0xa1, 0x02,                    //   COLLECTION (Logical)
//     0x09, 0x42,                    //     USAGE (Tip Switch)
//     0x15, 0x00,                    //     LOGICAL_MINIMUM (0)
//     0x25, 0x01,                    //     LOGICAL_MAXIMUM (1)
//     0x75, 0x01,                    //     REPORT_SIZE (1)
//     0x95, 0x01,                    //     REPORT_COUNT (1)
//     0x81, 0x02,                    //     INPUT (Data,Var,Abs)
//     0x95, 0x07,                    //     REPORT_COUNT (7)
//     0x81, 0x03,                    //     INPUT (Cnst,Var,Abs)
//     0x09, 0x51,                    //     USAGE (Contact identifier)
//     0x75, 0x08,                    //     REPORT_SIZE (8)
//     0x95, 0x01,                    //     REPORT_COUNT (1)
//     0x81, 0x02,                    //     INPUT (Data,Var,Abs)
//     0x05, 0x01,                    //     USAGE_PAGE (Generic Desktop)
//     0x75, 0x10,                    //     REPORT_SIZE (16)
//     0x55, 0x0e,                    //     UNIT_EXPONENT (-2)
//     0x65, 0x11,                    //     UNIT (SI Lin:Distance)
//     0x15, 0x00,                    //     LOGICAL_MINIMUM (0)
//     0x35, 0x00,                    //     PHYSICAL_MINIMUM (0)
//     0x09, 0x30,                    //     USAGE (X)
//     0x26, WBVAL(MAX_X_POS),        //     LOGICAL_MAXIMUM (0x7FFF = 32767)
//     0x46, WBVAL(MAX_SCREEN_LEN_X), //     PHYSICAL_MAXIMUM (0x14b4 = 5300)
//     0x81, 0x02,                    //     INPUT (Data,Var,Abs)
//     0x09, 0x31,                    //     USAGE (Y)
//     0x26, WBVAL(MAX_Y_POS),        //     LOGICAL_MAXIMUM (0x7FFF = 32767)
//     0x46, WBVAL(MAX_SCREEN_LEN_Y), //     PHYSICAL_MAXIMUM (0x0bb8 = 3000)
//     0x81, 0x02,                    //     INPUT (Data,Var,Abs)
//     0xc0,                          //   END_COLLECTION

//     /* finger#8 - 63 bytes */
//     0x05, 0x0d,                    //   USAGE_PAGE (Digitizers)
//     0x09, 0x22,                    //   USAGE (Finger #8)
//     0xa1, 0x02,                    //   COLLECTION (Logical)
//     0x09, 0x42,                    //     USAGE (Tip Switch)
//     0x15, 0x00,                    //     LOGICAL_MINIMUM (0)
//     0x25, 0x01,                    //     LOGICAL_MAXIMUM (1)
//     0x75, 0x01,                    //     REPORT_SIZE (1)
//     0x95, 0x01,                    //     REPORT_COUNT (1)
//     0x81, 0x02,                    //     INPUT (Data,Var,Abs)
//     0x95, 0x07,                    //     REPORT_COUNT (7)
//     0x81, 0x03,                    //     INPUT (Cnst,Var,Abs)
//     0x09, 0x51,                    //     USAGE (Contact identifier)
//     0x75, 0x08,                    //     REPORT_SIZE (8)
//     0x95, 0x01,                    //     REPORT_COUNT (1)
//     0x81, 0x02,                    //     INPUT (Data,Var,Abs)
//     0x05, 0x01,                    //     USAGE_PAGE (Generic Desktop)
//     0x75, 0x10,                    //     REPORT_SIZE (16)
//     0x55, 0x0e,                    //     UNIT_EXPONENT (-2)
//     0x65, 0x11,                    //     UNIT (SI Lin:Distance)
//     0x15, 0x00,                    //     LOGICAL_MINIMUM (0)
//     0x35, 0x00,                    //     PHYSICAL_MINIMUM (0)
//     0x09, 0x30,                    //     USAGE (X)
//     0x26, WBVAL(MAX_X_POS),        //     LOGICAL_MAXIMUM (0x7FFF = 32767)
//     0x46, WBVAL(MAX_SCREEN_LEN_X), //     PHYSICAL_MAXIMUM (0x14b4 = 5300)
//     0x81, 0x02,                    //     INPUT (Data,Var,Abs)
//     0x09, 0x31,                    //     USAGE (Y)
//     0x26, WBVAL(MAX_Y_POS),        //     LOGICAL_MAXIMUM (0x7FFF = 32767)
//     0x46, WBVAL(MAX_SCREEN_LEN_Y), //     PHYSICAL_MAXIMUM (0x0bb8 = 3000)
//     0x81, 0x02,                    //     INPUT (Data,Var,Abs)
//     0xc0,                          //   END_COLLECTION

//     /* finger#9 - 63 bytes */
//     0x05, 0x0d,                    //   USAGE_PAGE (Digitizers)
//     0x09, 0x22,                    //   USAGE (Finger #9)
//     0xa1, 0x02,                    //   COLLECTION (Logical)
//     0x09, 0x42,                    //     USAGE (Tip Switch)
//     0x15, 0x00,                    //     LOGICAL_MINIMUM (0)
//     0x25, 0x01,                    //     LOGICAL_MAXIMUM (1)
//     0x75, 0x01,                    //     REPORT_SIZE (1)
//     0x95, 0x01,                    //     REPORT_COUNT (1)
//     0x81, 0x02,                    //     INPUT (Data,Var,Abs)
//     0x95, 0x07,                    //     REPORT_COUNT (7)
//     0x81, 0x03,                    //     INPUT (Cnst,Var,Abs)
//     0x09, 0x51,                    //     USAGE (Contact identifier)
//     0x75, 0x08,                    //     REPORT_SIZE (8)
//     0x95, 0x01,                    //     REPORT_COUNT (1)
//     0x81, 0x02,                    //     INPUT (Data,Var,Abs)
//     0x05, 0x01,                    //     USAGE_PAGE (Generic Desktop)
//     0x75, 0x10,                    //     REPORT_SIZE (16)
//     0x55, 0x0e,                    //     UNIT_EXPONENT (-2)
//     0x65, 0x11,                    //     UNIT (SI Lin:Distance)
//     0x15, 0x00,                    //     LOGICAL_MINIMUM (0)
//     0x35, 0x00,                    //     PHYSICAL_MINIMUM (0)
//     0x09, 0x30,                    //     USAGE (X)
//     0x26, WBVAL(MAX_X_POS),        //     LOGICAL_MAXIMUM (0x7FFF = 32767)
//     0x46, WBVAL(MAX_SCREEN_LEN_X), //     PHYSICAL_MAXIMUM (0x14b4 = 5300)
//     0x81, 0x02,                    //     INPUT (Data,Var,Abs)
//     0x09, 0x31,                    //     USAGE (Y)
//     0x26, WBVAL(MAX_Y_POS),        //     LOGICAL_MAXIMUM (0x7FFF = 32767)
//     0x46, WBVAL(MAX_SCREEN_LEN_Y), //     PHYSICAL_MAXIMUM (0x0bb8 = 3000)
//     0x81, 0x02,                    //     INPUT (Data,Var,Abs)
//     0xc0,                          //   END_COLLECTION

//     /* 2 bytes */
//     0x05, 0x0d,                    //   USAGE_PAGE (Digitizers)

//     /* Contact Count - 10 bytes */
//     0x09, 0x54,                    //   USAGE (Contact count)
//     0x25, MAX_CONTACT_POINTS,      //   LOGICAL_MAXIMUM (0x14 = 20)
//     0x75, 0x08,                    //   REPORT_SIZE (8)
//     0x95, 0x01,                    //   REPORT_COUNT (1)
//     0x81, 0x02,                    //   INPUT (Data,Var,Abs)

//     /* Scan Time - 27 bytes */
//     0x09, 0x56,                    //   USAGE (Scan time)
//     0x66, 0x01, 0x10,              //   UNIT (SI Lin:Time)
//     0x55, 0x0c,                    //   UNIT_EXPONENT (-4)
//     0x15, 0x00,                    //   LOGICAL_MINIMUM (0)
//     0x27, 0xff, 0xff, 0x00, 0x00,  //   LOGICAL_MAXIMUM (65535, 6.5535 sec)
//     0x35, 0x00,                    //   PHYSICAL_MINIMUM (0)
//     0x47, 0xff, 0xff, 0x00, 0x00,  //   PHYSICAL_MAXIMUM (65535)
//     0x75, 0x10,                    //   REPORT_SIZE (16)
//     0x95, 0x01,                    //   REPORT_COUNT (1)
//     0x81, 0x02,                    //   INPUT (Data,Var,Abs)

// 	/* Contact Count Maximum Feature Report - Max # of contacts supported - 12 bytes */
//     0x85, REPORT_ID_MAX_CONTACT,   //   REPORT_ID (1)
//     0x09, 0x55,                    //   USAGE (Contact count maximum)
//     0x25, MAX_CONTACT_POINTS,      //   LOGICAL_MAXIMUM (0x14 = 20)
//     0x75, 0x08,                    //   REPORT_SIZE (8)
//     0x95, 0x01,                    //   REPORT_COUNT (1)
//     0xb1, 0x02,                    //   FEATURE (Data,Var,Abs)

// 	0xc0,                          // END_COLLECTION (Touch Screen)
// #endif
// 	/* Mouse Input Report - 59 bytes */
//     0x05, 0x01,                    // Usage Page(Generic Desktop)
//     0x09, 0x02,                    // Usage(Mouse)
//     0xA1, 0x01,                    // Collection(Application)
//     0x85, REPORT_ID_MOUSE,         //   Report Id(1)
//     0x09, 0x01,                    //   Usage(Pointer)
//     0xA1, 0x00,                    //   Collection(Physical)
//     0x05, 0x09,                    //     Usage Page(Button)
//     0x19, 0x01,                    //     USAGE_MINIMUM
//     0x29, 0x02,                    //     USAGE_MAXIMUM
//     0x15, 0x00,                    //     Logical minimum(0)
//     0x25, 0x01,                    //     Logical maximum(1)
//     0x75, 0x01,                    //     Report Size(1)
//     0x95, 0x02,                    //     Report Count(2)
//     0x81, 0x02,                    //     Input(Data,Value,Absolute,Bit Field)
//     0x95, 0x06,                    //     Report Count(6)
//     0x81, 0x03,                    //     Input(Constant,Value,Absolute,Bit Field)
//     0x05, 0x01,                    //     Usage Page(Generic Desktop)
//     0x09, 0x30,                    //     Usage(X)
//     0x15, 0x00,                    //     Logical minimum(0)
//     0x26, WBVAL(MAX_X_POS),        //     Logical maximum(xxxx)
//     0x09, 0x31,                    //     Usage(Y)
//     0x26, WBVAL(MAX_Y_POS),        //     Logical maximum(xxxx)
//     0x75, 0x10,                    //     Report Size(16)
//     0x95, 0x02,                    //     Report Count(2)
//     0x35, 0x00,                    //     PHYSICAL_MINIMUM
//     0x46, 0xFF, 0x7F,              //     PHYSICAL_MAXIMUM              //don't care
//     0x81, 0x02,                    //     Input(Data,Value,Absolute,Bit Field)
//     0xC0,                          //   End Collection
//     0xC0,                          // End Collection

//     /*
//      * Device Mode Feature Report to choose input mode - 28 bytes
//      * for Windows XP Tablet PC Edition and Windows Vista - single touch recommended
//      * for Windows XP and Microsoft Windows 2000 - mouse recommended
//      */
//     0x05, 0x0d,                    // USAGE_PAGE (Digitizers)
//     0x09, 0x0e,                    // USAGE (Device configuration)
//     0xa1, 0x01,                    // COLLECTION (Application)
//     0x85, REPORT_ID_DEVICE_MODE,   //   REPORT_ID (0x13)
//     0x09, 0x23,                    //   USAGE (Device settings)
//     0xa1, 0x02,                    //   COLLECTION (Logical)
//     0x09, 0x52,                    //     USAGE (Device mode)
//     0x09, 0x53,                    //     USAGE (Device identifier)
//     0x15, 0x00,                    //     LOGICAL_MINIMUM (0)
//     0x25, 0x0a,                    //     LOGICAL_MAXIMUM (10)
//     0x75, 0x08,                    //     REPORT_SIZE (8)
//     0x95, 0x02,                    //     REPORT_COUNT (2)
//     0xb1, 0x02,                    //     FEATURE (Data,Var,Abs)
//     0xc0,                          //   END_COLLECTION
//     0xc0,                          // END_COLLECTION
	
// 	/* Vendor Defined Feature Report - 31 bytes */
//     0x06, 0x00, 0xff,              // USAGE_PAGE (Generic Desktop)
//     0x09, 0x01,                    // USAGE (Vendor Usage 1)
//     0xa1, 0x01,                    // COLLECTION (Application)
//     0x15, 0x00,                    //   LOGICAL_MINIMUM (0)
//     0x26, 0xff, 0x00,              //   LOGICAL_MAXIMUM (255)
//     0x75, 0x08,                    //   REPORT_SIZE (8)
//     0x85, REPORT_ID_CUBER_CMD,     //   REPORT_ID (0x63 = 99)
//     0x09, 0x02,                    //   USAGE (Vendor Usage 2)
//     0x95, 0x0B,                    //   REPORT_COUNT (11)
//     0x91, 0x02,                    //   OUTPUT (Data,Var,Abs)
//     0x85, REPORT_ID_CUBER_DATA,    //   REPORT_ID (0x64 = 100)
//     0x09, 0x02,                    //   USAGE (Vendor Usage 2)
//     0x95, 0x3F,                    //   REPORT_COUNT (63)
//     0xb1, 0x02,                    //   FEATURE (Data,Var,Abs)
//     0xc0,                          // END_COLLECTION
// };

