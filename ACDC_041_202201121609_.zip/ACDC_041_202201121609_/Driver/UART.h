#ifndef _UART_H__
#define _UART_H__

#include "Includes.h"

void InitUART0(void);
void UART0_SendByte(uint8_t send_byte);

#endif