#ifndef _SYSTEM_H__
#define _SYSTEM_H__

#include "Includes.h"

void InitSystemClock(void);


#endif
