#ifndef _KEY_H__
#define _KEY_H__

#include "Includes.h"

#define bRIGHT_KEY			(1 << 5)
#define READ_RIGHT_KEY		(P0 & bRIGHT_KEY)

#define bDOWNLOAD_KEY		(1 << 6)
#define READ_DOWNLOAD_KEY	(P0 & bDOWNLOAD_KEY)

#define bLEFT_KEY			(1 << 7)
#define READ_LEFT_KEY		(P0 & bLEFT_KEY)

void InitGPIO_Key();


#endif